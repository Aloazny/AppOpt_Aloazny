### 蓝奏云下载地址(密码:111)
- [点击转跳](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式](https://aloazny.lanzouo.com/b00jeku6cd)
- [Ebpf版本(测试)](https://aloazny.lanzouv.com/b00jf0lz0h)
- [小飞机盘](https://share.feijipan.com/s/AN2lFUeN)

### 注意
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- [查看Flags文件说明](https://aloazny.github.io/AppOpt_Aloazny/#%E6%8F%90%E7%A4%BA)

### 更新日志
#### **30.9**
- 调整`cpu_control.sh`，`HyperOS[234]`对`foreground`去掉后台核心，`top`不动。
- 修正`6+2`(低性能)和`4+4`一个核心分配错误。
#### **30.8**
- 添加适配欧洲卡车模拟器3(`com.WandaSoftware.TruckersofEurope3`)。
- 修改`cpu_control.sh`脚本，对于`HyperOS[234]`的用户，前台(`foreground`/`top`)cpus一律去掉后台cpus，**尝试解决部分小米煞笔云控导致下拉通通知栏卡顿**。