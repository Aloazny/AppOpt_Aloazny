### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)
- [Ebpf版本(测试) 密码:111](https://aloazny.lanzouv.com/b00jf0lz0h)
- [小飞机盘](https://share.feijipan.com/s/AN2lFUeN)

### 注意
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- [查看Flags文件说明](https://aloazny.github.io/AppOpt_Aloazny/#%E6%8F%90%E7%A4%BA)

### 更新日志
> 29.1
- 添加App share (`info.muge.appshare`)适配。
> 29.0
- 添加Dola(豆包play版)(`com.larus.wolf`)适配。
- 添加异环(`com.hottagames.yh.laohu`)适配。
- 修复一个`limit_log_file`函数清空日志之后，nohup日志丢失问题。
- 优化`dex2oat`的prop修改数值，加快冷启动，具体查看`Aloazny.sh`(`action.sh`)和`system.prop`的注释。