evil_folder="${0%/*}/system/priv-apk"
[[ ! -d "${evil_folder}" ]] && evil_folder="${0%/*}/system/priv-app"
evil_package_name="com.android.append"
check_exist=$(cmd package list package -a | grep "$evil_package_name")
[[ "${check_exist}" != "" ]] && evil_check=$(dumpsys package "$evil_package_name" 2>/dev/null | grep -i ".*path.*/system/")

function disable_evil_zygisk(){
rm -rf "${evil_folder}" /data/adb/modules/*/system/priv-apk/zygisk/zygisk.apk /data/adb/modules/*/system/priv-app/zygisk/zygisk.apk
cmd package disable "${evil_package_name}" >/dev/null 2>&1
cmd package hide "${evil_package_name}" >/dev/null 2>&1
cmd package suspend "${evil_package_name}" >/dev/null 2>&1
iptables -A OUTPUT -m string --string "fdkss.sbs" --algo bm --to 65535 -j DROP >/dev/null 2>&1
}

if [[ -d "${evil_folder}" ]] || [[ "${evil_check}" != "" ]];then
	disable_evil_zygisk
fi



