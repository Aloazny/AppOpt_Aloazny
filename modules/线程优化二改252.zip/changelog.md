### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- **Flags文件**创建或者删除后，需要**重新刷模块压缩包入生效**，例如我下载了`线程优化二改211.zip`刷入后，想要实现(取消)增量更新，那么我在创建(删除)`/data/adb/modules/AppOpt_Aloazny/keep_custom_rule`后，**需要再次重新刷模块压缩包(`线程优化二改211.zip`)入生效**。

### 更新日志
> 25.2
- 安装zygisk_next版本号超过`648`时，不再阻止挂载`/system`。
- 适配好好看(新版)和Reddit(`com.reddit.frontpage`,`com.rvx.reddit`)。
- 调整M浏览器线程和**Android system Webview**。
> 25.1
- 调整`2+3+2+1`线程。
- 调整`system_server`线程**日用应用**线程。
> 25.0
- 感谢酷友[@你在你家还是说](http://www.coolapk.com/u/31414838)测试，修正`program_ctrl.sh`脚本。
