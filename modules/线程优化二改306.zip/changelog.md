### 蓝奏云下载地址(密码:111)
- [点击转跳](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式](https://aloazny.lanzouo.com/b00jeku6cd)
- [Ebpf版本(测试)](https://aloazny.lanzouv.com/b00jf0lz0h)
- [小飞机盘](https://share.feijipan.com/s/AN2lFUeN)

### 注意
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- [查看Flags文件说明](https://aloazny.github.io/AppOpt_Aloazny/#%E6%8F%90%E7%A4%BA)

### 更新日志
#### **30.6**
- 添加优酷(`com.youku.phone`)，四川集客(`com.inspur.mobilefsp`)适配。
- 调整低性能的`6+2`架构的`*.ui`/`*.raster`/`CrRendererMain`/`Chrome_InProcRe`/`Chrome_InProcGp`线程。
- 调整`4+4`架构的`CrRendererMain`/`Chrome_InProcRe`/`Chrome_InProcGp`和`RenderThread`线程。
#### **30.5**
- 添加三星机型机械性识别。
- 添加kards(`com.android1939.kardsapk`,`com.android1939.kards`)适配。