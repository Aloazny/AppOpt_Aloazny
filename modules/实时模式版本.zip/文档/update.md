## 线程优化二改实时模式版本
### 更新日志

> #### **提示(Tips)**
 - 如果没有特殊变化。
 - 一般跟随上游正式版本更新。
 - 具体更新日志，查看[changelog.md](https://aloazny.github.io/AppOpt_Aloazny/update/changelog.md)文件。

> 71
- 尝试修复未指定`priority.prop`的进程不会修改`applist.prop`对应存在进程的优先级，感谢[@coolapk 随心随心](http://www.coolapk.com/u/40536502)测试。
> 38
- 调整`SCHED_FIFO`和`SCHED_RR`时间，具体请查看`priority.sh`。
> 23
- 修复一个代码改动错误。
> v22
- 修复造成`SCHED_RESET_ON_FORK`可能造成的bug。
> v21
- 加入GIthub云更新。
> v12
- 无特殊更新，跟随上游211版本更新，请查看[changelog.md](./changelog.md)。
