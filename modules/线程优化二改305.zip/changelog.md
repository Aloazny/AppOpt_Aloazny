### 蓝奏云下载地址(密码:111)
- [点击转跳](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式](https://aloazny.lanzouo.com/b00jeku6cd)
- [Ebpf版本(测试)](https://aloazny.lanzouv.com/b00jf0lz0h)
- [小飞机盘](https://share.feijipan.com/s/AN2lFUeN)

### 注意
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- [查看Flags文件说明](https://aloazny.github.io/AppOpt_Aloazny/#%E6%8F%90%E7%A4%BA)

### 更新日志
#### **30.5**
- 添加三星机型机械性识别。
- 添加kards(`com.android1939.kardsapk`,`com.android1939.kards`)适配。
#### **30.4**
- 适配**Snapseed新版线程**。
- 添加搜书大师(`com.flyersoft.seekbooks`)、MTOOLS插件(`app.mtool.mtoolmobile.mkxpz`)、锤子音乐(`com.smartisanos.music`)适配。
- 添加魂斗罗：归来(`com.tencent.shootgame`)适配。