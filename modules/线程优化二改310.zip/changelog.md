### 蓝奏云下载地址(密码:111)
- [点击转跳](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式](https://aloazny.lanzouo.com/b00jeku6cd)
- [Ebpf版本(测试)](https://aloazny.lanzouv.com/b00jf0lz0h)
- [小飞机盘](https://share.feijipan.com/s/AN2lFUeN)

### 注意
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- [查看Flags文件说明](https://aloazny.github.io/AppOpt_Aloazny/#%E6%8F%90%E7%A4%BA)

### 更新日志
#### **31.0**
- 更新**Roblox/超自然行动组**线程。
- 添加适配敢达:争锋对决(`com.tencent.tmgp.gundambattle`)，奇葩战斗家(`com.leiting.daluandou.aligames`)，麻雀一番街(`com.riichicity.happywoods`)，星之翼(Starward)(`com.xzy.xgst`)，地平线行者(HorizonWalker)(`com.GentleManiac.HorizonWalker`)，现代战舰(`com.zhanhuo.mw`)。
- 更新`Asoulpackage.sh`脚本里与`Asoulopt`冲突的包名。
