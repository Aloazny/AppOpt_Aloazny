### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)
- [Ebpf版本(测试) 密码:111](https://aloazny.lanzouv.com/b00jf0lz0h)
- [小飞机盘](https://share.feijipan.com/s/AN2lFUeN)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- **Flags文件**创建或者删除后，需要**重新刷模块压缩包入生效**，例如我下载了`线程优化二改211.zip`刷入后，想要实现(取消)增量更新，那么我在创建(删除)`/data/adb/modules/AppOpt_Aloazny/Flags/keep_custom_rule`后，**需要再次重新刷模块压缩包(`线程优化二改211.zip`)入生效**。

### 更新日志
> 28.0
- 尝试修复**洛克王国部分页面卡死问题**。
- `cpu_control.sh`添加`zn-zygisk-companion`(zygisk)到小核心。
> 27.9
- 更改模块目录结构，Flags文件(`modtify`/`dex2oat_modtify`……)迁移至`模块目录/Flags`文件夹内。
- 脚本`program_ctrl.sh`/`cpu_control.sh……`迁移至`模块目录/Scripts`文件夹内。
- 已手动创建Flags文件的用户不用担心，模块会自动迁移旧的Flags文件。