#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>

struct event {
    int pid;
    int tid;
    char comm[16];
};

struct {
    __uint(type, BPF_MAP_TYPE_PERF_EVENT_ARRAY);
    __uint(key_size, sizeof(int));
    __uint(value_size, sizeof(int));
} events SEC(".maps");

// 更老的写法
// tracepoint/sched/sched_process_fork
// tracepoint/sched/sched_process_exec
// tracepoint:sched:sched_process_fork

SEC("tp/sched/sched_process_fork")
int tp_fork(void *ctx)
{
    struct event e = {};
    unsigned long long pid_tgid = bpf_get_current_pid_tgid();
    
    e.pid = (int)(pid_tgid >> 32);
    e.tid = (int)pid_tgid;
    
    bpf_get_current_comm(&e.comm, sizeof(e.comm));
    bpf_perf_event_output(ctx, &events, BPF_F_CURRENT_CPU, &e, sizeof(e));
    return 0;
}

SEC("tp/sched/sched_process_exec")
int tp_exec(void *ctx)
{
    struct event e = {};
    unsigned long long pid_tgid = bpf_get_current_pid_tgid();
    
    e.pid = (int)(pid_tgid >> 32);
    e.tid = (int)pid_tgid;
    
    bpf_get_current_comm(&e.comm, sizeof(e.comm));
    bpf_perf_event_output(ctx, &events, BPF_F_CURRENT_CPU, &e, sizeof(e));
    return 0;
}

char LICENSE[] SEC("license") = "GPL";