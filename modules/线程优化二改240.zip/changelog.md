### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- **Flags文件**创建或者删除后，需要**重新刷模块压缩包入生效**，例如我下载了`线程优化二改211.zip`刷入后，想要实现(取消)增量更新，那么我在创建(删除)`/data/adb/modules/AppOpt_Aloazny/keep_custom_rule`后，**需要再次重新刷模块压缩包(`线程优化二改211.zip`)入生效**。

### 更新日志
> 24.0
- 添加Next player (`dev.anilbeesetti.nextplayer`)，VLC player (`org.videolan.vlc`)，- Pixel桌面 (`com.google.android.apps.nexuslauncher`)，launcher3桌面 (`com.android.launcher3`)，OneUI桌面 (`com.sec.android.app.launcher`)，NOVA桌面(`com.teslacoilsw.launcher`)，Square Home(`com.ss.squarehome2`)，微软桌面(microsoft launcher)(`com.microsoft.launcher`)适配。
- 完善蛋仔派对其他渠道服匹配，添加`Blibili服`/`小米服`/`vivo服`……。
- 移除`ColorsOS`部分系统应用线程规则。
> 23.9
- 添加Reex(`xyz.re.player.ex`)适配。
- 适配`KB视频工厂`老版本的一个线程。