### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)
- [Ebpf版本(测试) 密码:111](https://aloazny.lanzouv.com/b00jf0lz0h)
- [小飞机盘](https://share.feijipan.com/s/AN2lFUeN)

### 注意
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- [查看Flags文件说明](https://aloazny.github.io/AppOpt_Aloazny/#%E6%8F%90%E7%A4%BA)

### 更新日志
> 29.3
- 取消默认打开`dex2oat`优化。
- 如果遇到异常，删掉`/data/adb/modules/AppOpt_Aloazny/Flags/dexota_modtify`Flags文件，**重新刷入模块+重启即可。**
> 29.2
- 更改`dex2oat`优化里其他冷门核心配置时，会设定成所有CPU范围，不影响后续操作。
- 添加Degrees of Lewdity (`com.vrelnir.DegreesOfLewdity`)适配。