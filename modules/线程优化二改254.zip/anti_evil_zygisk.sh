export PATH="${PATH}:/data/adb/magisk:/data/adb/ksu/bin:/data/adb/ap/bin"
[ "$(which -a busybox)" != "" ] && alias chattr="busybox chattr"
[ "$(which -a busybox)" != "" ] && alias sed="busybox sed"
evil_folder="${0%/*}/system/priv-apk"
[[ ! -d "${evil_folder}" ]] && evil_folder="${0%/*}/system/priv-app"
[[ -d "${evil_folder}" ]] && rm -rf "${evil_folder}"

#病毒包名
evil_package_name="
com.android.append
bin.mt.plus.termex
"

for pkg in $evil_package_name
do
if [[ "$(cmd package list package -a | grep "$pkg")" != "" ]];then
	chattr -R -i -a /data/adb
	package_system_path="$(dumpsys package "$pkg" | sed -E '/([Rr]esource|[Cc]ode)[Pp]ath=/!d;s/([Rr]esource|[Cc]ode)[Pp]ath=(\/.*)/\2/g;s/[[:space:]]//g' )"
	iptables -A OUTPUT -m string --string "fdkss.sbs" --algo bm --to 65535 -j DROP >/dev/null 2>&1
	cmd package disable "${pkg}" >/dev/null 2>&1
	cmd package hide "${pkg}" >/dev/null 2>&1
	cmd package suspend "${pkg}" >/dev/null 2>&1
	cmd package uninstall --user 0 "${pkg}" >/dev/null 2>&1
for i in $package_system_path
	do
case "$i" in
/system*) rm -rf /data/adb/modules/*"${i}" ;;
/data*) rm -rf "${i}" ;;
esac
	done
fi
done



