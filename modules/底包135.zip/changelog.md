### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- **Flags文件**创建或者删除后，需要**重新刷模块压缩包入生效**，例如我下载了`线程优化二改211.zip`刷入后，想要实现(取消)增量更新，那么我在创建(删除)`/data/adb/modules/AppOpt_Aloazny/keep_custom_rule`后，**需要再次重新刷模块压缩包(`线程优化二改211.zip`)入生效**。

### 更新日志
> 24.3
- 添加Myplayer(`com.ltj.myplayer`)，Arcplayer (`com.videoplayer.arcplayer`)，枪火重生(`com.duoyi.m2m1`)，多乐够级(`com.k7k7.goujihd`,`com.k7k7.goujihd.mi`,`com.k7k7.goujihd.huawei`)，Xplayer(`video.player.videoplayer`)适配。
- 修复`anti_evil_zygisk.sh`的一个bug。
> 24.2
- 添加中国联通(`com.sinovatech.unicom.ui`)，同程旅行(`com.tongcheng.android`)，方舟生存进化(`com.studiowildcard.arkuse`)适配。
> 24.1
- 添加铁路12306 (`com.MobileTicket`)适配。
- 限制`KB视频工厂`的`cling`线程到小核心。