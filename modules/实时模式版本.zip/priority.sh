#设置线程任务时间占用合理性(其实保持默认就好)
#避免卡死
#默认值950000
#SCHED_FIFO
RUN_Time="900000"
#默认值1000000
PD_Time="1000000"
#默认值100
#SCHED_RR在一个任务上运行的时间
RR_Time="200"

RUN_Time_File="/proc/sys/kernel/sched_rt_runtime_us"
PD_Time_File="/proc/sys/kernel/sched_rt_period_us"
RR_Time_File="/proc/sys/kernel/sched_rr_timeslice_ms"
Last_RUN_Time=`cat ${RUN_Time_File}`
Last_PD_Time=`cat ${PD_Time_File}`
Last_RR_Time=`cat ${RR_Time_File}`

#if [ "${Last_RUN_Time}" = "-1" -o "${Last_RUN_Time}" -ge "1000000" -o "${Last_RUN_Time}" = "0" ];then
	chmod 0644 "${RUN_Time_File}" 2>/dev/null
	echo "${RUN_Time}" > "${RUN_Time_File}"
	echo "- ${RUN_Time_File##*/}: ${Last_RUN_Time} >> ${RUN_Time}"
	chmod 0444 "${RUN_Time_File}" 2>/dev/null
#fi

if [ "${Last_PD_Time}" = "-1" -o "${Last_PD_Time}" -gt "${PD_Time}" -o "${PD_Time}" = "0" ];then
	chmod 0644 "${PD_Time_File}" 2>/dev/null
	echo "${PD_Time}" > "${PD_Time_File}"
	echo "- ${PD_Time_File##*/}: ${Last_PD_Time} >> ${PD_Time}"
	chmod 0444 "${PD_Time_File}" 2>/dev/null
fi

#if [ "${Last_RR_Time}" = "0" ];then
	chmod 0644 "${RR_Time_File}" 2>/dev/null
	echo "${RR_Time}" > "${RR_Time_File}"
	echo "- ${RR_Time_File##*/}: ${Last_RR_Time} >> ${RR_Time}"
	chmod 0444 "${RR_Time_File}" 2>/dev/null
#fi
