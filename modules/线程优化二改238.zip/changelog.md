### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- **Flags文件**创建或者删除后，需要**重新刷模块压缩包入生效**，例如我下载了`线程优化二改211.zip`刷入后，想要实现(取消)增量更新，那么我在创建(删除)`/data/adb/modules/AppOpt_Aloazny/keep_custom_rule`后，**需要再次重新刷模块压缩包(`线程优化二改211.zip`)入生效**。

### 更新日志
> 23.8
- 添加格式工厂(`com.geshi.formatfactory`)，可口的比萨(`com.tapblaze.pizzabusiness`)，风云格式工厂(`net.windcloud.explorer`)适配。
- 适配`idm+(1dm+)`新版本线程。
> 23.7
- 添加雀魂麻将(`com.soulgamechst.majsoul`)，MMRL (`com.dergoogler.mmrl`)，线程优化管理(`com.AppOptManager`)适配。
- 调整MIUI的CPU亲和系统`prop`值。