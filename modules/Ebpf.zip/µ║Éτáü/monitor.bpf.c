#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>


#define __NR_sched_setaffinity 122

enum event_type {
    EVENT_FORK = 1,
    EVENT_EXEC = 2,
    EVENT_SET_AFFINITY = 3,
};

struct event {
    int pid;
    int tid;
    char comm[16];
    int type;
};

// 用来存储过滤一些EVENT_EXEC(应用启动包括二进制sh/sleep之类的)
// 没有BTF应该也能用
struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 256);
    __uint(key_size, 16);
    __uint(value_size, sizeof(int));
} filter_map SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_PERF_EVENT_ARRAY);
    __uint(key_size, sizeof(int));
    __uint(value_size, sizeof(int));
} events SEC(".maps");

static __always_inline void report_event(void *ctx, int event_type) {
    char comm[16];
    bpf_get_current_comm(&comm, sizeof(comm));
    if (event_type != EVENT_FORK && bpf_map_lookup_elem(&filter_map, &comm)) {
        return;
    }
    struct event e = {};
    unsigned long long pid_tgid = bpf_get_current_pid_tgid();
    e.pid = pid_tgid >> 32; 
    e.tid = (unsigned int)pid_tgid;
    e.type = event_type;
    __builtin_memcpy(e.comm, comm, sizeof(e.comm));
    bpf_perf_event_output(ctx, &events, BPF_F_CURRENT_CPU, &e, sizeof(e));
}

SEC("raw_tracepoint/sched_process_fork")
int rt_fork(struct bpf_raw_tracepoint_args *ctx) {
    report_event(ctx, EVENT_FORK);
    return 0;
}

SEC("raw_tracepoint/sched_process_exec")
int rt_exec(struct bpf_raw_tracepoint_args *ctx) {
    report_event(ctx, EVENT_EXEC);
    return 0;
}

SEC("tp/sched/sched_process_fork")
int tp_fork(void *ctx) {
    report_event(ctx, EVENT_FORK);
    return 0;
}

SEC("tp/sched/sched_process_exec")
int tp_exec(void *ctx) {
    report_event(ctx, EVENT_EXEC);
    return 0;
}

SEC("raw_tracepoint/sys_enter")
int rt_sys_enter(struct bpf_raw_tracepoint_args *ctx) {
    if (ctx->args[0] != __NR_sched_setaffinity) return 0;
    report_event(ctx, EVENT_SET_AFFINITY);
    return 0;
}

SEC("tp/syscalls/sys_enter_sched_setaffinity")
int tp_sys_setaffinity(void *ctx) {
    report_event(ctx, EVENT_SET_AFFINITY);
    return 0;
}

char LICENSE[] SEC("license") = "GPL";
