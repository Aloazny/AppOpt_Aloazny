#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <fnmatch.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/sysinfo.h>
#include <time.h>
#include <unistd.h>
#include <stdarg.h>
#include <bpf/libbpf.h>
#include <bpf/bpf.h>
#include "monitor.skel.h"
#include "uthash.h"

#define VERSION            "1.3.5-Ebpf"
#define BASE_CPUSET        "/dev/cpuset/system-control-apps"
#define MAX_PKG_LEN        128
#define MAX_THREAD_LEN     32
#define INITIAL_RULE_CAPACITY 8192
#define INITIAL_WILDCARD_CAPACITY 256
#define DENT_BUF_SIZE (128 * 1024)
#define MAX_PROC_CACHE     4096

#define LOG_I(fmt, ...) do { write_log("[I] " fmt, ##__VA_ARGS__); } while (0)
#define LOG_W(fmt, ...) do { write_log("[W] " fmt, ##__VA_ARGS__); } while (0)
#define LOG_E(fmt, ...) do { write_log("[E] " fmt, ##__VA_ARGS__); } while (0)

struct event { 
    int pid; 
    int tid; 
    char comm[16];
};

typedef struct {
    char pkg[MAX_PKG_LEN];
    char thread[MAX_THREAD_LEN];
    char cpuset_dir[256];
    cpu_set_t cpus;
    bool is_wildcard;
    int priority;
} AffinityRule;

typedef struct {
    pid_t tid;
    cpu_set_t cpus;
    char cpuset_dir[256];
    time_t last_applied;
} ThreadCache;

typedef struct {
    pid_t pid;
    char pkg[MAX_PKG_LEN];
    ThreadCache* threads;
    size_t num_threads;
    size_t threads_cap;
} ProcessCache;

typedef struct {
    cpu_set_t present_cpus;
    char present_str[128];
    char mems_str[32];
    bool cpuset_enabled;
    int base_cpuset_fd;
} CpuTopology;

typedef struct PackageEntry {
    char pkg[MAX_PKG_LEN];
    UT_hash_handle hh;
} PackageEntry;

typedef struct {
    atomic_int ref_count;
    AffinityRule* rules;
    size_t num_rules;
    AffinityRule** wildcard_rules;
    size_t num_wildcard_rules;
    time_t mtime;
    CpuTopology topo;
    struct PackageEntry* pkg_table;
    char config_file[4096];
    char cpuset_base[256];
} AppConfig;

typedef struct {
    ProcessCache* procs;
    size_t num_procs;
    size_t procs_cap;
    atomic_int event_counter;
    time_t last_scan_time;
} GlobalCache;

struct linux_dirent64 {
    ino64_t d_ino; off64_t d_off; unsigned short d_reclen;
    unsigned char d_type; char d_name[];
};

static _Atomic(AppConfig*) current_config = NULL;
static GlobalCache global_cache = {0};

static void write_log(const char *fmt, ...) {
    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);
    char time_str[20];
    strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", tm_info);
    fprintf(stderr, "[%s] ", time_str);
    va_list args; va_start(args, fmt);
    vfprintf(stderr, fmt, args); va_end(args);
    fflush(stderr);
}

static char* strtrim(char* s) {
    char* end;
    while (isspace(*s)) s++;
    if (*s == 0) return s;
    end = s + strlen(s) - 1;
    while (end > s && isspace(*end)) end--;
    *(end + 1) = 0;
    return s;
}

static char* strtrim_line(char* s) {
    char* start = s;
    while (isspace((unsigned char)*start)) start++;
    if (!*start) return start;
    char* end = start + strlen(start) - 1;
    while (end > start && (isspace((unsigned char)*end) || *end == '#')) end--;
    end[1] = '\0';
    return start;
}

static bool read_file(int dir_fd, const char* filename, char* buf, size_t buf_size) {
    int fd = openat(dir_fd, filename, O_RDONLY | O_CLOEXEC);
    if (fd == -1) return false;
    ssize_t n = read(fd, buf, buf_size - 1);
    close(fd);
    if (n <= 0) return false;
    buf[n] = '\0'; return true;
}

static bool write_file(int dir_fd, const char* filename, const char* content, int flags) {
    int fd = openat(dir_fd, filename, flags | O_CLOEXEC, 0644);
    if (fd == -1) return false;
    ssize_t n = write(fd, content, strlen(content));
    close(fd);
    return (n == (ssize_t)strlen(content));
}

static int build_str(char *dest, size_t dest_size, ...) {
    va_list args; const char *segment; char *p = dest;
    size_t remaining = dest_size - 1;
    va_start(args, dest_size);
    while ((segment = va_arg(args, const char *)) != NULL) {
        size_t len = strlen(segment);
        if (len > remaining) { va_end(args); return 0; }
        memcpy(p, segment, len); p += len; remaining -= len;
    }
    *p = '\0'; va_end(args); return 1;
}

static bool parse_cpu_ranges(const char* spec, cpu_set_t* set, const cpu_set_t* present, char* invalid_buf) {
    if (!spec) return true;
    char* copy = strdup(spec); if (!copy) return false;
    char* s = copy; bool all_valid = true;
    while (*s) {
        char* end;
        unsigned long a = strtoul(s, &end, 0);
        if (end == s) { s++; continue; }
        unsigned long b = a;
        if (*end == '-') { s = end + 1; b = strtoul(s, &end, 10); if (end == s) b = a; }
        for (unsigned long i = a; i <= b && i < CPU_SETSIZE; i++) {
            if (present && !CPU_ISSET(i, present)) {
                if (invalid_buf) sprintf(invalid_buf, "%lu", i);
                all_valid = false; continue;
            }
            CPU_SET(i, set);
        }
        s = (*end == ',') ? end + 1 : end;
    }
    free(copy); return all_valid;
}

static char* cpu_set_to_str(const cpu_set_t *set) {
    size_t buf_size = 8 * CPU_SETSIZE; char *buf = malloc(buf_size); if (!buf) return NULL;
    int start = -1, end = -1; char *p = buf; size_t remain = buf_size - 1; bool first = true;
    for (int i = 0; i < CPU_SETSIZE; i++) {
        if (CPU_ISSET(i, set)) {
            if (start == -1) start = end = i;
            else if (i == end + 1) end = i;
            else {
                int needed = (start == end) ? snprintf(p, remain + 1, "%s%d", first ? "" : ",", start) : snprintf(p, remain + 1, "%s%d-%d", first ? "" : ",", start, end);
                p += needed; remain -= needed; start = end = i; first = false;
            }
        }
    }
    if (start != -1) {
        if (start == end) snprintf(p, remain + 1, "%s%d", first ? "" : ",", start);
        else snprintf(p, remain + 1, "%s%d-%d", first ? "" : ",", start, end);
    }
    return buf;
}

static bool create_cpuset_dir(const char *path, const char *cpus, const char *mems) {
    if (mkdir(path, 0755) != 0 && errno != EEXIST) return false;
    chmod(path, 0755); chown(path, 0, 0);
    char cpus_path[256], mems_path[256];
    build_str(cpus_path, sizeof(cpus_path), path, "/cpus", NULL);
    write_file(AT_FDCWD, cpus_path, cpus, O_WRONLY | O_CREAT | O_TRUNC);
    build_str(mems_path, sizeof(mems_path), path, "/mems", NULL);
    write_file(AT_FDCWD, mems_path, mems, O_WRONLY | O_CREAT | O_TRUNC);
    return true;
}

static CpuTopology init_cpu_topo(void) {
    CpuTopology topo = { .cpuset_enabled = false, .base_cpuset_fd = -1 };
    CPU_ZERO(&topo.present_cpus);
    if (read_file(AT_FDCWD, "/sys/devices/system/cpu/present", topo.present_str, sizeof(topo.present_str))) strtrim(topo.present_str);
    parse_cpu_ranges(topo.present_str, &topo.present_cpus, NULL, NULL);
    if (access("/dev/cpuset", F_OK) == 0) {
        if (create_cpuset_dir(BASE_CPUSET, topo.present_str, "0")) {
            topo.base_cpuset_fd = open(BASE_CPUSET, O_RDONLY | O_DIRECTORY);
            if (topo.base_cpuset_fd != -1) topo.cpuset_enabled = true;
        }
        char mem_p[256]; build_str(mem_p, 256, BASE_CPUSET, "/mems", NULL);
        if (!read_file(AT_FDCWD, mem_p, topo.mems_str, 32)) strcpy(topo.mems_str, "0"); else strtrim(topo.mems_str);
    }
    return topo;
}

static int calculate_rule_priority(const char* thread) {
    if (!thread || !*thread) return 100;
    if (strchr(thread, '*') == NULL && strchr(thread, '?') == NULL && strchr(thread, '[') == NULL) {
        return 1000 + strlen(thread);
    }
    return 500 + strlen(thread);
}

static AppConfig* get_config() {
    AppConfig* cfg = atomic_load_explicit(&current_config, memory_order_acquire);
    if (cfg) atomic_fetch_add(&cfg->ref_count, 1); 
    return cfg;
}

static void config_release(AppConfig* cfg) {
    if (cfg && atomic_fetch_sub(&cfg->ref_count, 1) == 1) {
        free(cfg->rules); 
        free(cfg->wildcard_rules);
        PackageEntry *e, *tmp; 
        HASH_ITER(hh, cfg->pkg_table, e, tmp) { 
            HASH_DEL(cfg->pkg_table, e); 
            free(e); 
        }
        free(cfg);
    }
}

static AppConfig* load_config(const char* config_file, const CpuTopology* topo, time_t* last_mtime) {
    struct stat st;
    if (stat(config_file, &st) != 0) {
        const char* init = "# 规则编写与使用说明请参考 http://AppOpt.suto.top\n\n";
        if (write_file(AT_FDCWD, config_file, init, O_WRONLY | O_CREAT | O_TRUNC))
            LOG_W("配置文件不存在，创建空的配置文件: %s\n", config_file);
        return NULL;
    }
    if (last_mtime && *last_mtime == st.st_mtime) return NULL;

    FILE *fp = fopen(config_file, "r");
    if (!fp) { LOG_E("无法打开配置文件 %s: %s\n", config_file, strerror(errno)); return NULL; }

    AppConfig* cfg = calloc(1, sizeof(AppConfig));
    if (!cfg) { fclose(fp); return NULL; }
    cfg->ref_count = 1; 
    cfg->topo = *topo;
    cfg->num_rules = 0; 
    cfg->num_wildcard_rules = 0;
    build_str(cfg->config_file, sizeof(cfg->config_file), config_file, NULL);
    build_str(cfg->cpuset_base, sizeof(cfg->cpuset_base), BASE_CPUSET, NULL);

    size_t r_cap = INITIAL_RULE_CAPACITY, w_cap = INITIAL_WILDCARD_CAPACITY;
    cfg->rules = malloc(r_cap * sizeof(AffinityRule));
    cfg->wildcard_rules = malloc(w_cap * sizeof(AffinityRule*));
    if (!cfg->rules || !cfg->wildcard_rules) { 
        fclose(fp); 
        free(cfg->rules); 
        free(cfg->wildcard_rules); 
        free(cfg); 
        return NULL; 
    }

    char line[512]; 
    size_t ln = 0;
    while (fgets(line, sizeof(line), fp)) {
        ln++; 
        char* p = strtrim_line(line); 
        if (!*p || *p == '#') continue;
        
        char* eq = strchr(p, '=');
        if (!eq) { LOG_W("第 %zu 行无效规则：缺少 '=': %s\n", ln, p); continue; }
        *eq++ = '\0'; 
        char *key = strtrim(p), *val = strtrim(eq);
        char* comment = strchr(val, '#'); 
        if (comment) *comment = '\0';
        val = strtrim(val); 
        if (!*key || !*val) { LOG_W("第 %zu 行无效规则：键或值为空: %s\n", ln, p); continue; }

        char *br = strchr(key, '{'), *thread = "";
        if (br) {
            *br++ = '\0'; 
            char* eb = strchr(br, '}');
            if (!eb) { LOG_W("第 %zu 行无效规则：缺少闭合 '}': %s\n", ln, p); continue; }
            *eb = '\0'; 
            thread = strtrim(br);
        }

        char* pkg = strtrim(key);
        if (strlen(pkg) >= MAX_PKG_LEN || strlen(thread) >= MAX_THREAD_LEN) { 
            LOG_W("第 %zu 行无效规则：包名或线程名过长\n", ln); 
            continue; 
        }

        if (cfg->num_rules >= r_cap) {
            r_cap *= 2; 
            AffinityRule* old = cfg->rules;
            cfg->rules = realloc(cfg->rules, r_cap * sizeof(AffinityRule));
            if (!cfg->rules) { 
                fclose(fp); 
                free(old); 
                free(cfg->wildcard_rules); 
                free(cfg); 
                return NULL; 
            }
        }

        AffinityRule* r = &cfg->rules[cfg->num_rules++];
        strncpy(r->pkg, pkg, MAX_PKG_LEN - 1); 
        strncpy(r->thread, thread, MAX_THREAD_LEN - 1);
        CPU_ZERO(&r->cpus); 
        char inv[64] = {0};
        if (!parse_cpu_ranges(val, &r->cpus, &cfg->topo.present_cpus, inv)) {
            LOG_W("第 %zu 行无效 CPU 范围：%s 在规则 %s{%s}=%s，超出可用 CPU (%s)\n", ln, inv, pkg, thread, val, cfg->topo.present_str);
            cfg->num_rules--;
            continue;
        }
        if (CPU_COUNT(&r->cpus) == 0) { 
            LOG_W("第 %zu 行无效 CPU 范围：无有效 CPU\n", ln); 
            cfg->num_rules--;
            continue; 
        }

        char* dn = cpu_set_to_str(&r->cpus);
        if (dn) {
            char path[512]; 
            build_str(path, 512, cfg->cpuset_base, "/", dn, NULL);
            if (!create_cpuset_dir(path, dn, cfg->topo.mems_str)) { 
                LOG_W("第 %zu 行无法创建 cpuset 目录 %s\n", ln, path); 
                free(dn); 
                cfg->num_rules--;
                continue; 
            }
            strncpy(r->cpuset_dir, dn, 255); 
            free(dn);
        } else {
            r->cpuset_dir[0] = '\0';
        }

        r->is_wildcard = (strchr(pkg, '*') || strchr(pkg, '?') || strchr(pkg, '['));
        r->priority = calculate_rule_priority(thread);

        if (!r->is_wildcard) {
            PackageEntry* pe; 
            HASH_FIND_STR(cfg->pkg_table, pkg, pe);
            if (!pe) { 
                pe = calloc(1, sizeof(PackageEntry)); 
                strncpy(pe->pkg, pkg, MAX_PKG_LEN - 1); 
                HASH_ADD_STR(cfg->pkg_table, pkg, pe); 
            }
        } else {
            if (cfg->num_wildcard_rules >= w_cap) { 
                w_cap *= 2; 
                cfg->wildcard_rules = realloc(cfg->wildcard_rules, w_cap * sizeof(AffinityRule*)); 
            }
            cfg->wildcard_rules[cfg->num_wildcard_rules++] = r;
        }
    }
    fclose(fp);
    
    if (cfg->num_rules == 0) { 
        LOG_W("从 %s 未加载有效规则\n", config_file); 
        config_release(cfg); 
        return NULL; 
    }
    
    cfg->mtime = st.st_mtime; 
    if (last_mtime) *last_mtime = st.st_mtime;
    
    LOG_I("配置文件解析完成，共加载 %zu 条规则，%zu 个应用，%zu 条通配符规则\n", 
          cfg->num_rules, (size_t)HASH_COUNT(cfg->pkg_table), cfg->num_wildcard_rules);
    return cfg;
}

static ProcessCache* find_or_create_proc_cache(pid_t pid, const char* pkg) {
    for (size_t i = 0; i < global_cache.num_procs; i++) {
        if (global_cache.procs[i].pid == pid) {
            if (strcmp(global_cache.procs[i].pkg, pkg) != 0) {
                if (global_cache.procs[i].threads) {
                    free(global_cache.procs[i].threads);
                    global_cache.procs[i].threads = NULL;
                }
                strncpy(global_cache.procs[i].pkg, pkg, MAX_PKG_LEN - 1);
                global_cache.procs[i].num_threads = 0;
                global_cache.procs[i].threads_cap = 0;
            }
            return &global_cache.procs[i];
        }
    }
    
    if (global_cache.num_procs >= global_cache.procs_cap) {
        size_t new_cap = global_cache.procs_cap ? global_cache.procs_cap * 2 : 64;
        ProcessCache* new_procs = realloc(global_cache.procs, new_cap * sizeof(ProcessCache));
        if (!new_procs) return NULL;
        global_cache.procs = new_procs;
        global_cache.procs_cap = new_cap;
    }
    
    ProcessCache* pc = &global_cache.procs[global_cache.num_procs++];
    memset(pc, 0, sizeof(ProcessCache));
    pc->pid = pid;
    strncpy(pc->pkg, pkg, MAX_PKG_LEN - 1);
    pc->threads = NULL;
    pc->num_threads = 0;
    pc->threads_cap = 0;
    
    return pc;
}


static ThreadCache* find_or_create_thread_cache(ProcessCache* pc, pid_t tid) {
    for (size_t i = 0; i < pc->num_threads; i++) {
        if (pc->threads[i].tid == tid) {
            return &pc->threads[i];
        }
    }
    
    if (pc->num_threads >= pc->threads_cap) {
        size_t new_cap = pc->threads_cap ? pc->threads_cap * 2 : 16;
        ThreadCache* new_threads = realloc(pc->threads, new_cap * sizeof(ThreadCache));
        if (!new_threads) return NULL;
        pc->threads = new_threads;
        pc->threads_cap = new_cap;
    }
    
    ThreadCache* tc = &pc->threads[pc->num_threads++];
    memset(tc, 0, sizeof(ThreadCache));
    tc->tid = tid;
    CPU_ZERO(&tc->cpus);
    tc->cpuset_dir[0] = '\0';
    tc->last_applied = 0;
    
    return tc;
}

static void apply_affinity_to_thread(pid_t tid, const cpu_set_t* cpus, const char* cpuset_dir, const CpuTopology* topo) {
    if (CPU_COUNT(cpus) == 0) return;
    
    if (topo->cpuset_enabled && cpuset_dir && cpuset_dir[0]) {
        char ts[32];
        snprintf(ts, sizeof(ts), "%d\n", tid);
        int cfd = openat(topo->base_cpuset_fd, cpuset_dir, O_RDONLY | O_DIRECTORY);
        if (cfd != -1) {
            write_file(cfd, "tasks", ts, O_WRONLY | O_APPEND);
            close(cfd);
        }
    }
    
    sched_setaffinity(tid, sizeof(cpu_set_t), cpus);
}

static AffinityRule* find_best_rule(const char* pkg, const char* thread, AppConfig* cfg) {
    AffinityRule* best = NULL; int best_priority = -1;
    for (size_t i = 0; i < cfg->num_rules; i++) {
        AffinityRule* r = &cfg->rules[i]; bool pkg_match = false;
        if (r->is_wildcard) { if (fnmatch(r->pkg, pkg, 0) == 0) pkg_match = true; }
        else { if (strcmp(r->pkg, pkg) == 0) pkg_match = true; }
        if (!pkg_match) continue;
        
        int priority = 0;
        if (r->thread[0]) {
            if (strcmp(r->thread, thread) == 0) priority = r->priority + 1000;
            else if (fnmatch(r->thread, thread, 0) == 0) priority = r->priority;
            else continue;
        } else priority = r->priority;
        
        if (priority > best_priority) { best_priority = priority; best = r; }
    }
    return best;
}

static void handle_event_from_ebpf(struct event *e) {
    AppConfig* cfg = get_config();
    if (!cfg) return;
    
    char pkg[MAX_PKG_LEN] = {0}, path[64];
    snprintf(path, sizeof(path), "/proc/%d/cmdline", e->tid);
    int fd = open(path, O_RDONLY);
    if (fd != -1) {
        ssize_t n = read(fd, pkg, MAX_PKG_LEN - 1);
        if (n > 0) {
            pkg[n] = '\0'; char* slash = strrchr(pkg, '/');
            if (slash) memmove(pkg, slash + 1, strlen(slash + 1) + 1);
        }
        close(fd);
    }
    
    if (!pkg[0]) return;
    PackageEntry* pe; HASH_FIND_STR(cfg->pkg_table, pkg, pe);
    bool matched = (pe != NULL);
    for (size_t i = 0; !matched && i < cfg->num_wildcard_rules; i++)
        if (fnmatch(cfg->wildcard_rules[i]->pkg, pkg, 0) == 0) matched = true;
    
    if (!matched) { config_release(cfg); return; }
    
    time_t now = time(NULL);
    ProcessCache* pc = find_or_create_proc_cache(e->pid, pkg);
    ThreadCache* tc = pc ? find_or_create_thread_cache(pc, e->tid) : NULL;
    
    if (!tc || tc->last_applied > now - 2) { config_release(cfg); return; }
    
    AffinityRule* rule = find_best_rule(pkg, e->comm, cfg);
    if (rule) {
        if (memcmp(&tc->cpus, &rule->cpus, sizeof(cpu_set_t)) != 0 || strcmp(tc->cpuset_dir, rule->cpuset_dir) != 0) {
            CPU_ZERO(&tc->cpus); CPU_OR(&tc->cpus, &tc->cpus, &rule->cpus);
            strncpy(tc->cpuset_dir, rule->cpuset_dir, 255);
            apply_affinity_to_thread(e->tid, &rule->cpus, rule->cpuset_dir, &cfg->topo);
            tc->last_applied = now;
        }
    }
    config_release(cfg);
}

static void handle_ebpf_event(void *ctx, int cpu, void *data, unsigned int data_sz) {
    struct event *e = data;
    atomic_fetch_add(&global_cache.event_counter, 1);
    handle_event_from_ebpf(e);
}

static void cleanup_dead_processes(void) {
    size_t i = 0;
    while (i < global_cache.num_procs) {
        if (kill(global_cache.procs[i].pid, 0) != 0) {
            if (global_cache.procs[i].threads) {
                free(global_cache.procs[i].threads);
                global_cache.procs[i].threads = NULL;
            }
            if (i < global_cache.num_procs - 1) {
                global_cache.procs[i] = global_cache.procs[global_cache.num_procs - 1];
                memset(&global_cache.procs[global_cache.num_procs - 1], 0, sizeof(ProcessCache));
            } else {
                memset(&global_cache.procs[i], 0, sizeof(ProcessCache));
            }
            global_cache.num_procs--;
        } else {
            i++;
        }
    }
}

static void cleanup_global_cache(void) {
    if (global_cache.procs) {
        for (size_t i = 0; i < global_cache.num_procs; i++) {
            if (global_cache.procs[i].threads) {
                free(global_cache.procs[i].threads);
                global_cache.procs[i].threads = NULL;
            }
        }
        free(global_cache.procs);
        global_cache.procs = NULL;
    }
    global_cache.num_procs = 0;
    global_cache.procs_cap = 0;
    atomic_store(&global_cache.event_counter, 0);
}

static void incremental_scan(AppConfig* cfg) {
    char* buf = malloc(DENT_BUF_SIZE);
    int pfd = open("/proc", O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (pfd == -1) { free(buf); return; }
    
    while (1) {
        int n = syscall(__NR_getdents64, pfd, (struct linux_dirent64*)buf, DENT_BUF_SIZE);
        if (n <= 0) break;
        for (int pos = 0; pos < n; ) {
            struct linux_dirent64* ent = (struct linux_dirent64*)(buf + pos);
            if (ent->d_type == DT_DIR && isdigit(ent->d_name[0])) {
                int pid = atoi(ent->d_name), exists = 0;
                for (size_t i = 0; i < global_cache.num_procs; i++)
                    if (global_cache.procs[i].pid == pid) { exists = 1; break; }
                
                if (!exists) {
                    char path[64]; snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);
                    int fd = open(path, O_RDONLY);
                    if (fd != -1) {
                        char pkg[MAX_PKG_LEN] = {0};
                        ssize_t n_read = read(fd, pkg, MAX_PKG_LEN - 1); close(fd);
                        if (n_read > 0) {
                            pkg[n_read] = '\0'; char* slash = strrchr(pkg, '/');
                            if (slash) memmove(pkg, slash + 1, strlen(slash + 1) + 1);
                            
                            PackageEntry* pe; HASH_FIND_STR(cfg->pkg_table, pkg, pe);
                            bool matched = (pe != NULL);
                            for (size_t i = 0; !matched && i < cfg->num_wildcard_rules; i++)
                                if (fnmatch(cfg->wildcard_rules[i]->pkg, pkg, 0) == 0) matched = true;
                            
                            if (matched) {
                                struct event e = { .pid = pid, .tid = pid };
                                int tfd = openat(pfd, ent->d_name, O_RDONLY | O_DIRECTORY);
                                if (tfd != -1) {
                                    char comm[16] = {0}; read_file(tfd, "comm", comm, sizeof(comm));
                                    strtrim(comm); strncpy(e.comm, comm, 15); close(tfd);
                                }
                                handle_event_from_ebpf(&e);
                            }
                        }
                    }
                }
            }
            pos += ent->d_reclen;
        }
    }
    free(buf); close(pfd);
}

static void print_help(const char* prog_name) {
    printf("用法: %s [选项]\n", prog_name);
    printf("选项:\n");
    printf("  -c <配置文件>   指定配置文件 (默认: ./applist.conf)\n");
    printf("  -v             显示程序版本\n");
    printf("  -h             显示帮助信息\n");
    printf("\n示例:\n");
    printf("  %s -c /data/applist.conf\n", prog_name);
}

int main(int argc, char **argv) {
    CpuTopology topo = init_cpu_topo(); 
    char config_file[4096] = "./applist.conf"; 
    int opt, config_check_counter = 0, scan_counter = 0;
    
    while ((opt = getopt(argc, argv, "c:vh")) != -1) {
        if (opt == 'c') strncpy(config_file, optarg, sizeof(config_file)-1);
        else if (opt == 'v') { printf("AppOpt %s\n", VERSION); return 0; }
        else if (opt == 'h') { print_help(argv[0]); return 0; }
    }
    
    time_t config_mtime = 0;
    AppConfig* initial = load_config(config_file, &topo, &config_mtime);
    if (!initial) { LOG_E("初始化配置失败: %s\n", config_file); return 1; }
    atomic_store(&current_config, initial);
    
    struct monitor_bpf *skel = monitor_bpf__open_and_load();
    if (skel) monitor_bpf__attach(skel);
    struct perf_buffer *pb = skel ? perf_buffer__new(bpf_map__fd(skel->maps.events), 8, handle_ebpf_event, NULL, NULL, NULL) : NULL;
    
    LOG_I("启动AppOpt服务 v%s [eBPF:%s] [PID:%d]\n", VERSION, pb ? "ON" : "OFF", getpid());
    
    while (1) {
        if (pb) perf_buffer__poll(pb, 100); else sleep(1);

        if (++config_check_counter >= 100) {
            config_check_counter = 0; struct stat st;
            if (stat(config_file, &st) == 0 && st.st_mtime != config_mtime) {
                AppConfig* new_cfg = load_config(config_file, &topo, &config_mtime);
                if (new_cfg) {
                    AppConfig* old = atomic_exchange(&current_config, new_cfg);
                    config_release(old); 
                    LOG_I("配置文件已更新，正在清理旧缓存...\n");
                    cleanup_global_cache();
                }
            }
        }
        
        if (++scan_counter >= 300) {
            scan_counter = 0; 
            cleanup_dead_processes();
            if (atomic_exchange(&global_cache.event_counter, 0) == 0) {
                AppConfig* cfg = get_config();
                if (cfg) { incremental_scan(cfg); config_release(cfg); }
            }
        }
    }
    return 0;
}