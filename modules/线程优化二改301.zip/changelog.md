### 蓝奏云下载地址(密码:111)
- [点击转跳](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式](https://aloazny.lanzouo.com/b00jeku6cd)
- [Ebpf版本(测试)](https://aloazny.lanzouv.com/b00jf0lz0h)
- [小飞机盘](https://share.feijipan.com/s/AN2lFUeN)

### 注意
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- [查看Flags文件说明](https://aloazny.github.io/AppOpt_Aloazny/#%E6%8F%90%E7%A4%BA)

### 更新日志
#### **30.1**
- 添加CDisplayEx(`com.progdigy.cdisplay`)、Kuro.Reader.Pro(新版)、ComiChu.X(`glanium.comiczx`)、Reeden(`app.reeden`)、EhViewer(`moe.tarsin.ehviewer`)、Eros-FE(`com.honjow.fehviewer`)适配。
#### **30.0**
- 修复一个`core_architect_set`函数对冷门架构为未完全分配性能核心的bug。
- 添加Momogram (`momo.gram`)适配。