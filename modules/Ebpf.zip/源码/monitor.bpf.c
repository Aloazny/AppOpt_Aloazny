#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>

struct event {
    int pid;
    int tid;
    char comm[16];
};

struct {
    __uint(type, BPF_MAP_TYPE_PERF_EVENT_ARRAY);
    __uint(key_size, sizeof(int));
    __uint(value_size, sizeof(int));
} events SEC(".maps");

SEC("raw_tracepoint/sched_process_fork")
int raw_tracepoint__sched_process_fork(struct bpf_raw_tracepoint_args *ctx)
{
    struct event e = {};
    
    unsigned long long pid_tgid = bpf_get_current_pid_tgid();
    e.pid = pid_tgid >> 32;
    e.tid = (unsigned int)pid_tgid;
    
    bpf_get_current_comm(&e.comm, sizeof(e.comm));
    
    bpf_perf_event_output(ctx, &events, BPF_F_CURRENT_CPU, &e, sizeof(e));
    return 0;
}

SEC("raw_tracepoint/sched_process_exec")
int raw_tracepoint__sched_process_exec(struct bpf_raw_tracepoint_args *ctx)
{
    struct event e = {};
    
    unsigned long long pid_tgid = bpf_get_current_pid_tgid();
    e.pid = pid_tgid >> 32;
    e.tid = (unsigned int)pid_tgid;
    
    bpf_get_current_comm(&e.comm, sizeof(e.comm));
    
    bpf_perf_event_output(ctx, &events, BPF_F_CURRENT_CPU, &e, sizeof(e));
    return 0;
}

char LICENSE[] SEC("license") = "GPL";