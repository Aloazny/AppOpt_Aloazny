### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)
- [Ebpf版本(测试) 密码:111](https://aloazny.lanzouv.com/b00jf0lz0h)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- **Flags文件**创建或者删除后，需要**重新刷模块压缩包入生效**，例如我下载了`线程优化二改211.zip`刷入后，想要实现(取消)增量更新，那么我在创建(删除)`/data/adb/modules/AppOpt_Aloazny/keep_custom_rule`后，**需要再次重新刷模块压缩包(`线程优化二改211.zip`)入生效**。

### 更新日志
> 27.4
- 对**系统进程**的线程进行删减调整，感谢酷友[@se贩卖日落](coolmarket://u/22066711)测试。
- 添加永恒之塔2(AION2)(`com.nctaiwan.aion2`)，300大作战 (`com.jumpw.mobile300`,`com.jumpw.mobile.huawei`,`com.jumpw.mobile300.mi`,`com.jumpw.mobile.bilibili`,`com.tencent.tmgp.jumpw`)，鹅鸭杀(`com.seayoo.ggd`,`com.tencent.tmgp.seayoo.ggd`)适配。
- 感谢酷友[@寂jehdj](coolmarket://u/17461632)、[@lvshujun](coolmarket://u/33911820)提供线程图。
- **本次更新建议重启**。