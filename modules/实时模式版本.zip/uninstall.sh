uninstall_module(){
while [ "$(getprop sys.boot_completed)" != "1" ]; do
	sleep 3m
done
if [ "$(pgrep -f oiface)" = "" ];then
	if [ -n "$(getprop persist.sys.oiface.enable)" ]; then
		prop_value=$(grep -E '^persist\.sys\.oiface\.enable=' /system_ext/etc/build.prop | cut -d= -f2)
  	  if [ -n "$prop_value" ]; then
		 	resetprop persist.sys.oiface.enable "$prop_value"
		else
			resetprop persist.sys.oiface.enable 2
		fi
	fi
fi
until $(dumpsys deviceidle get screen) ;do
	sleep 2m
done
pm enable com.xiaomi.joyose >/dev/null 2>&1
pm enable com.xiaomi.joyose/.smartop.SmartOpService >/dev/null 2>&1
#staging为测试服，russia为俄罗斯服，international为国际服，china为国服。
am broadcast -a update_profile --es cloud_current_enviroment china -n com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
#staging为测试服，russia为俄罗斯服，international为国际服，official为国服。
am broadcast -a update_profile --es profile_server official -n com.xiaomi.joyose/.cloud.CloudServerReceiver
}

#修复MT管理器26040453版本的卸载bug，其他MT管理器版本没这问题
#这个版本没法后台运行卸载脚本，只能前台
if [ -d "/data/user/0" ] ;then
	uninstall_module
else
	( uninstall_module &)
fi
