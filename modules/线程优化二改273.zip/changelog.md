### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)
- [Ebpf版本(测试) 密码:111](https://aloazny.lanzouv.com/b00jf0lz0h)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- **Flags文件**创建或者删除后，需要**重新刷模块压缩包入生效**，例如我下载了`线程优化二改211.zip`刷入后，想要实现(取消)增量更新，那么我在创建(删除)`/data/adb/modules/AppOpt_Aloazny/keep_custom_rule`后，**需要再次重新刷模块压缩包(`线程优化二改211.zip`)入生效**。

### 更新日志
> 27.3
- 添加白羊音乐(`com.baiyang.music`)，Nagram XF(`fork.risin42.nagram`,`fork.risin42.nagramx`)，GitHub Store(`zed.rainxch.githubstore`)，Free Download Manager(`org.freedownloadmanager.fdm`)适配。
- 添加N.O.V.A3(近地轨道联盟先遣队3)(`com.gameloft.android.ANMP.GloftNAHM`)适配。
- 感谢酷友@[bvgib_gk](http://www.coolapk.com/u/5314215)提供的线程图。
> 27.2
- 添加小爱离线/AI字幕翻译(4.16~4.30版本) (`com.xiaomi.aiasst.vision`)，HMA-OSS(`org.frknkrc44.hma_oss`)适配。
- 调整**萤火突击**和**好好看**线程。