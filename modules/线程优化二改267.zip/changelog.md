### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)
- [Ebpf版本(测试) 密码:111](https://aloazny.lanzouv.com/b00jf0lz0h)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- **Flags文件**创建或者删除后，需要**重新刷模块压缩包入生效**，例如我下载了`线程优化二改211.zip`刷入后，想要实现(取消)增量更新，那么我在创建(删除)`/data/adb/modules/AppOpt_Aloazny/keep_custom_rule`后，**需要再次重新刷模块压缩包(`线程优化二改211.zip`)入生效**。


### 更新日志
> 26.7
- 补充适配阅读(`com.legado.app.release`)/王牌竞速(`com.netease.aceracer.huawei`)。
- 尝试修复实时模式版本的一些Bug，感谢[@coolapk 随心随心](http://www.coolapk.com/u/40536502)测试。
> 26.6
- 添加Github(`com.github.android`)，floccus同步 (`org.handmadeideas.floccus`)，蓝云(`com.tooyoung.lanzou`)适配。
- 添加明日方舟终末地 (`com.hypergryph.endfield`)适配。