### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)
- [Ebpf版本(测试) 密码:111](https://aloazny.lanzouv.com/b00jf0lz0h)
- [小飞机盘](https://share.feijipan.com/s/AN2lFUeN)

### 注意
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- [查看Flags文件说明](https://aloazny.github.io/AppOpt_Aloazny/#%E6%8F%90%E7%A4%BA)

### 更新日志
#### **29.9**
- 紧急修复一个在部分系统里内核的`related_cpus`显示为`0-1`导致识别核心错误分配的bug。
- 添加NP管理器(`com.wn.app.np`)适配。
- 适配**MT管理器某些插件的网络线程**。
#### **29.8**
- 适配MTOOLS新版本的兼容模式下的线程(此模式是Gecko+Canvas，性能很差，发热严重，非必要不要选)。
- 更新`get_cpu_core_Info`函数，信息显示更准确清晰一些。