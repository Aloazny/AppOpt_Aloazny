> ### Ebpf测试版本
- 没有Ebpf时会退回轮询……
- 内核需要到5.20以后支持才完整，有的内核没有BTF/vmlinux数据……
- 目前我是用硬编码手动解析`raw_tracepoint`数据来跳过`vmlinux.h`依赖
- 目前先做个测试……
- 后续再说


> ### 更新日志

> v3
- 添加一个`AppOpt.419`，兼容`Linux.4.19`版本，用的是`tracepoint`，理论上用`raw_tracepoint`性能更好。
> v2
 - 修复可能的**内存泄露**。
> v1
 - 去除`-s`参数
 - 去除对`BTF`依赖，兼容更多设备。